"""Reporting components for document forensics."""

from .report_manager import ReportManager

__all__ = ['ReportManager']